/*
 */
package WeatherApp;

/*
 * @author: Nicholas.Eber
 * @created: Apr 18, 2017
 */
public class Weather {
    public static String city = "City";
    public static String state = "State";
    public static String code = "Code";
    public static String date = "Date";
    public static String day = "Day";
    public static String high = "High";
    public static String low = "Low";
    public static String text = "Text";
}
